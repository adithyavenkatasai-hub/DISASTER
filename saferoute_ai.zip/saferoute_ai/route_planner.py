"""Route scoring, algorithm dispatch, alternative-route ranking and shelter ranking."""
from __future__ import annotations
import time
import algorithms as alg

ALGORITHMS = ["Dijkstra", "Bellman-Ford", "Heap-based optimizer"]
STATUS_USABLE = ("Available", "Limited Capacity")


def _search(adj, algo, s, t):
    """Returns (path, cost). Raises alg errors for invalid graphs."""
    if algo == "Dijkstra":
        r = alg.dijkstra(adj, s, t)
        return alg.reconstruct_path(r.prev, s, t), r.dist.get(t, alg.INF)
    if algo == "Bellman-Ford":
        p, c, _ = alg.shortest_path_bf(adj, s, t)
        return p, c
    res = alg.k_shortest_paths(adj, s, t, k=1)
    return (res[0][1], res[0][0]) if res else ([], alg.INF)


def _route(rg, path, cost, algo, ms, closed, label):
    m = rg.path_metrics(path, closed)
    names = [rg.nodes[n]["name"] for n in path]
    return {"label": label, "algorithm": algo, "path": path, "cost": round(cost, 2), "exec_ms": round(ms, 3),
            "names": names, **m}


def run_algorithm(rg, algo, s, t, objective, hw, closed):
    adj = rg.adjacency(objective, hw, closed)
    t0 = time.perf_counter()
    path, cost = _search(adj, algo, s, t)
    ms = (time.perf_counter() - t0) * 1000
    if not path:
        return None
    return _route(rg, path, cost, algo, ms, closed, "Recommended route")


def _overlap(a, b):
    ea, eb = set(a), set(b)
    return len(ea & eb) / max(1, min(len(ea), len(eb)))


def alternatives(rg, s, t, objective, hw, closed, primary, n=2, pool=25):
    """Heap-based candidate generation, then keep routes that differ meaningfully (<70% shared roads)."""
    adj = rg.adjacency(objective, hw, closed)
    kept = [primary["edge_ids"]]
    out = []
    for cost, path in alg.k_shortest_paths(adj, s, t, k=pool):
        m = rg.path_metrics(path, closed)
        if all(_overlap(m["edge_ids"], k) < 0.7 for k in kept):
            kept.append(m["edge_ids"])
            out.append(_route(rg, path, cost, "Heap-based optimizer", 0.0, closed, f"Alternative {len(out) + 1}"))
        if len(out) >= n:
            break
    return out


def explain(rg, route, s, t, objective, hw, closed):
    base = run_algorithm(rg, "Dijkstra", s, t, "Shortest distance", hw, closed)
    parts = [f"{route['algorithm']} minimised a non-negative '{objective}' cost over {route['segments']} road segments, "
             f"skipping {len(closed)} closed or restricted segment(s)."]
    if base and base["edge_ids"] != route["edge_ids"]:
        cmp = (f"The shortest-distance route is {base['distance_km']} km (hazard exposure {base['exposure']}); "
               f"this route is {route['distance_km']} km (exposure {route['exposure']}). ")
        if base["exposure"] > route["exposure"]:
            cmp += "Here the shortest route is more exposed, so it was not chosen: shortest is not always safest."
        else:
            cmp += "Under this objective the route is chosen for the selected cost (e.g. speed or congestion), not for lowest exposure."
        parts.append(cmp)
    elif base:
        parts.append("It is also the shortest-distance route in this scenario.")
    if route["exposure"] > 0:
        parts.append("It still crosses areas marked as hazardous in the (sample/simulated) hazard data; "
                     "follow official instructions.")
    return " ".join(parts)


def plan_route(rg, s, t, algo, objective, hw, closed, n_alt=2):
    """Full plan: primary route, alternatives, and an all-algorithm comparison."""
    if s == t:
        return {"status": "same", "message": "Origin and destination are the same location."}
    try:
        primary = run_algorithm(rg, algo, s, t, objective, hw, closed)
    except (alg.NegativeCycleError, alg.NegativeWeightError) as e:
        return {"status": "invalid", "message": f"Route rejected: {e}"}
    if not primary:
        return {"status": "no_route", "message": "No valid route exists with the current closures. "
                "Contact local emergency authorities; do not rely on this prototype."}
    primary["explanation"] = explain(rg, primary, s, t, objective, hw, closed)
    alts = alternatives(rg, s, t, objective, hw, closed, primary, n_alt)
    comp = {a: run_algorithm(rg, a, s, t, objective, hw, closed) for a in ALGORITHMS}
    return {"status": "ok", "primary": primary, "alternatives": alts, "comparison": comp}


def rank_shelters(rg, origin, shelters, objective, hw, closed):
    """Usable shelters (Available / Limited Capacity) ordered by route cost from origin."""
    r = alg.dijkstra(rg.adjacency(objective, hw, closed), origin)
    out = []
    for s in shelters:
        if s["status"] in STATUS_USABLE and s["node"] in r.dist:
            path = alg.reconstruct_path(r.prev, origin, s["node"])
            out.append({**s, "cost": r.dist[s["node"]], "distance_km": rg.path_metrics(path, closed)["distance_km"]})
    return sorted(out, key=lambda x: x["cost"])


def share_text(shelter_name, route):
    return (f"I'm safe. Heading to {shelter_name}; estimated {route['time_min']:.0f} min "
            f"({route['distance_km']} km, sample estimate).")
