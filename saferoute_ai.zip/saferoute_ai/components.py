"""Reusable UI pieces. All dynamic text is HTML-escaped."""
from __future__ import annotations
import html
import os
import streamlit as st

DISCLAIMER = ("SafeRoute AI is an educational prototype. It does not replace emergency services or official "
              "evacuation orders. Data shown is sample, simulated or unverified.")


def inject_css():
    css = open(os.path.join(os.path.dirname(__file__), "styles.css"), encoding="utf-8").read()
    st.markdown(f"<style>{css}</style>", unsafe_allow_html=True)


def h(x):
    return html.escape(str(x))


def md(s):
    st.markdown(s.replace("\n", ""), unsafe_allow_html=True)


def banner(text, kind="info"):
    icon = {"info": "ℹ️", "warn": "⚠️", "danger": "🚨", "ok": "✅", "sim": "🧪"}[kind]
    md(f'<div class="sr-banner sr-{kind}"><span>{icon}</span><div>{text}</div></div>')


def metric(label, value, sub="", tone=""):
    md(f'<div class="sr-metric {tone}"><div class="sr-mlabel">{h(label)}</div><div class="sr-mvalue">{h(value)}</div>'
       f'<div class="sr-msub">{h(sub)}</div></div>')


def gauge(pct, title, sub, color="#1fd1b4"):
    """Donut gauge (SVG), like the occupancy rings of the incident tracking layout."""
    pct = max(0, min(100, pct))
    c = 251.2
    md(f'<div class="sr-gauge"><svg viewBox="0 0 100 100" role="img" aria-label="{h(title)} {pct:.0f} percent">'
       f'<circle cx="50" cy="50" r="40" fill="none" stroke="#2a3a5c" stroke-width="9"/>'
       f'<circle cx="50" cy="50" r="40" fill="none" stroke="{color}" stroke-width="9" stroke-linecap="round" '
       f'stroke-dasharray="{c * pct / 100:.1f} {c}" transform="rotate(-90 50 50)"/>'
       f'<text x="50" y="57" text-anchor="middle" fill="#e8eefc" font-size="20" font-weight="700">{pct:.0f}%</text></svg>'
       f'<div class="sr-gt">{h(title)}</div><div class="sr-gs">{h(sub)}</div></div>')


def notification(level, text, meta):
    col = {"High": "#ff4d5e", "Medium": "#ff9f1c", "Low": "#1fd1b4"}.get(level, "#9fb0cf")
    md(f'<div class="sr-note" style="border-left-color:{col}"><b style="color:{col}">{h(level)} risk</b> '
       f'<span>{h(text)}</span><div class="sr-msub">{h(meta)}</div></div>')


def route_card(route, dest_name):
    """Blue guidance card modelled on the mobile 'safest driving route' layout."""
    md(f'<div class="sr-route"><div class="sr-rarrow">↑</div><div><div class="sr-rtime">{route["time_min"]:.0f} min '
       f'<small>({route["distance_km"]} km)</small></div><div>To {h(dest_name)}. Avoids all known closed roads; '
       f'hazard exposure {route["exposure"]}/100.</div></div></div>')


def status_badge(status):
    cls = {"Available": "ok", "Limited Capacity": "warn", "Full": "danger", "Unverified": "muted"}[status]
    return f'<span class="sr-badge {cls}">{h(status)}</span>'
