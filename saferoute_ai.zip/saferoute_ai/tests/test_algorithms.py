import os, sys, random, tempfile, unittest
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.environ["SAFEROUTE_DB"] = os.path.join(tempfile.mkdtemp(), "t.db")
import networkx as nx
import algorithms as alg, data_loader as dl, graph_manager as gm, route_planner as rp, database as db

ADJ = {"A": [("B", 4), ("C", 2)], "B": [("D", 5)], "C": [("B", 1), ("D", 8)], "D": []}


class TestAlgorithms(unittest.TestCase):
    def test_dijkstra_known(self):
        r = alg.dijkstra(ADJ, "A", "D")
        self.assertEqual(alg.reconstruct_path(r.prev, "A", "D"), ["A", "C", "B", "D"])
        self.assertEqual(r.dist["D"], 8)

    def test_dijkstra_rejects_negative(self):
        with self.assertRaises(alg.NegativeWeightError):
            alg.dijkstra({"A": [("B", -1)], "B": []}, "A")

    def test_bellman_ford_negative_edge(self):
        edges = [("A", "B", 4), ("A", "C", 5), ("C", "B", -3), ("B", "D", 2)]
        r = alg.bellman_ford("ABCD", edges, "A")
        self.assertFalse(r.negative_cycle)
        self.assertEqual(r.dist["B"], 2)

    def test_bellman_ford_detects_cycle(self):
        edges = [("A", "B", 1), ("B", "C", -3), ("C", "B", 1)]
        r = alg.bellman_ford("ABC", edges, "A")
        self.assertTrue(r.negative_cycle)
        self.assertEqual(set(r.cycle_nodes), {"B", "C"})

    def test_unreachable_negative_cycle_ignored(self):
        edges = [("A", "B", 1), ("X", "Y", -3), ("Y", "X", 1)]
        self.assertFalse(alg.bellman_ford("ABXY", edges, "A").negative_cycle)

    def test_bf_route_refuses_negative_physical_weights(self):
        with self.assertRaises(alg.NegativeWeightError):
            alg.shortest_path_bf({"A": [("B", -2)], "B": []}, "A", "B")

    def test_k_shortest_sorted_and_loopfree(self):
        res = alg.k_shortest_paths(ADJ, "A", "D", k=5)
        costs = [c for c, _ in res]
        self.assertEqual(costs, sorted(costs))
        self.assertEqual(costs[0], 8)
        self.assertTrue(all(len(set(p)) == len(p) for _, p in res))

    def test_matches_networkx_random(self):
        rng = random.Random(1)
        for _ in range(20):
            G = nx.gnp_random_graph(12, 0.3, seed=rng.randrange(999))
            adj = {n: [] for n in G}
            for u, v in G.edges:
                w = rng.uniform(1, 9); G[u][v]["weight"] = w
                adj[u].append((v, w)); adj[v].append((u, w))
            for t in range(1, 12):
                if nx.has_path(G, 0, t):
                    expect = nx.dijkstra_path_length(G, 0, t)
                    self.assertAlmostEqual(alg.dijkstra(adj, 0, t).dist[t], expect)
                    self.assertAlmostEqual(alg.shortest_path_bf(adj, 0, t)[1], expect)
                    self.assertAlmostEqual(alg.k_shortest_paths(adj, 0, t, k=1)[0][0], expect)


class TestPlanner(unittest.TestCase):
    def setUp(self):
        self.nodes, self.roads, _ = dl.build_demo_network()
        db.init_db(self.roads)
        self.rg = gm.RoadGraph(self.nodes, self.roads)

    def test_all_algorithms_agree_and_skip_closures(self):
        plan = rp.plan_route(self.rg, "N40", "N12", "Dijkstra", gm.OBJECTIVES[0], 3, frozenset())
        self.assertEqual(plan["status"], "ok")
        costs = {round(r["cost"], 4) for r in plan["comparison"].values()}
        self.assertEqual(len(costs), 1)
        blocked = frozenset(plan["primary"]["edge_ids"][:1])
        plan2 = rp.plan_route(self.rg, "N40", "N12", "Dijkstra", gm.OBJECTIVES[0], 3, blocked)
        self.assertNotIn(list(blocked)[0], plan2["primary"]["edge_ids"])
        self.assertEqual(plan2["primary"]["closed_hits"], 0)

    def test_no_route_when_isolated(self):
        closed = frozenset(r["id"] for r in self.roads if "N40" in (r["u"], r["v"]))
        self.assertEqual(rp.plan_route(self.rg, "N40", "N12", "Dijkstra", gm.OBJECTIVES[0], 3, closed)["status"], "no_route")

    def test_hazard_aversion(self):
        base = rp.run_algorithm(self.rg, "Dijkstra", "N40", "N12", gm.OBJECTIVES[0], 3, frozenset())
        self.rg.apply_zones([gm.make_zone(self.nodes["N31"], "Flood", "High", "t", "test")])
        safe = rp.run_algorithm(self.rg, "Dijkstra", "N40", "N12", gm.OBJECTIVES[0], 8, frozenset())
        fast = rp.run_algorithm(self.rg, "Dijkstra", "N40", "N12", "Fastest", 8, frozenset())
        self.assertLessEqual(safe["exposure"], fast["exposure"])

    def test_shelter_status_rules(self):
        self.assertEqual(db.shelter_status(100, 100, 1), "Full")
        self.assertEqual(db.shelter_status(100, 90, 1), "Limited Capacity")
        self.assertEqual(db.shelter_status(100, 10, 0), "Unverified")
        with self.assertRaises(ValueError):
            db.save_shelter({"name": "x", "node": "N00", "capacity": 10, "occupied": 11})


if __name__ == "__main__":
    unittest.main()
