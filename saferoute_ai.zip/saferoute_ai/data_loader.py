"""Sample data. The demo network is SYNTHETIC: coordinates sit near Yogyakarta only so the
base map has a familiar backdrop. None of these roads, shelters or incidents are real."""
from __future__ import annotations
import math
import random
import networkx as nx

CENTER = (-7.7956, 110.3695)
ROWS, COLS = 5, 6
NAMES = ["Riverside", "Old Market", "Central Square", "Harbor Gate", "Hilltop", "Garden Park",
         "Station Road", "City Hall", "Lakeview", "Mill Lane", "Bridge Point", "Fort Junction",
         "University Gate", "Sunrise Ave", "West End", "Orchard Cross", "Temple Hill", "Canal Side",
         "North Ridge", "South Basin", "Eastfield", "Clock Tower", "Palm Junction", "Quarry Cross",
         "Meadow Point", "Stadium Gate", "Airport Link", "Ferry Landing", "Pine Heights", "Green Valley"]
DEMO_LABEL = "Demonstration network (synthetic sample data, not real roads)"


def haversine_km(lat1, lon1, lat2, lon2):
    p1, p2 = math.radians(lat1), math.radians(lat2)
    a = (math.sin((p2 - p1) / 2) ** 2
         + math.cos(p1) * math.cos(p2) * math.sin(math.radians(lon2 - lon1) / 2) ** 2)
    return 6371.0 * 2 * math.asin(math.sqrt(a))


def edge_id(u, v):
    a, b = sorted((u, v))
    return f"{a}-{b}"


def build_demo_network(seed=7):
    """Returns (nodes, roads, pois). Deterministic for a given seed."""
    rng = random.Random(seed)
    step = 0.0092
    nodes = {}
    for r in range(ROWS):
        for c in range(COLS):
            nid = f"N{r}{c}"
            nodes[nid] = {
                "id": nid, "name": NAMES[r * COLS + c],
                "lat": CENTER[0] + (2 - r) * step + rng.uniform(-0.0018, 0.0018),
                "lon": CENTER[1] + (c - 2.5) * step + rng.uniform(-0.0018, 0.0018)}
    pairs = []
    for r in range(ROWS):
        for c in range(COLS):
            if c + 1 < COLS:
                pairs.append((f"N{r}{c}", f"N{r}{c+1}", r == 2))        # row 2 = arterial
            if r + 1 < ROWS:
                pairs.append((f"N{r}{c}", f"N{r+1}{c}", c in (2, 3)))   # cols 2,3 = arterial
    for _ in range(5):                                                   # a few diagonals
        r, c = rng.randrange(ROWS - 1), rng.randrange(COLS - 1)
        pairs.append((f"N{r}{c}", f"N{r+1}{c+1}", False))
    G = nx.Graph()
    G.add_edges_from((u, v) for u, v, _ in pairs)
    locals_ = [p for p in pairs if not p[2]]
    rng.shuffle(locals_)
    dropped = 0
    for u, v, _ in locals_:                      # thin out the grid but keep it connected
        if dropped >= 4:
            break
        G.remove_edge(u, v)
        if nx.is_connected(G) and min(dict(G.degree()).values()) >= 2:
            pairs.remove((u, v, False)); dropped += 1
        else:
            G.add_edge(u, v)
    roads = []
    for u, v, arterial in pairs:
        a, b = nodes[u], nodes[v]
        length = haversine_km(a["lat"], a["lon"], b["lat"], b["lon"]) * 1.15
        roads.append({"id": edge_id(u, v), "u": u, "v": v, "length_km": round(length, 3),
                      "speed_kmh": 50 if arterial else 30,
                      "road_type": "Arterial" if arterial else "Local",
                      "congestion": round(rng.uniform(0.0, 0.5), 2),
                      "name": f"{a['name']} - {b['name']}"})
    pois = [{"name": "Demo General Hospital", "kind": "hospital", "node": "N21"},
            {"name": "Demo Fire Station", "kind": "fire", "node": "N11"},
            {"name": "Demo Police Post", "kind": "police", "node": "N32"}]
    return nodes, roads, pois


def seed_shelters():
    # source documents WHY a record may be shown as verified; blank source => Unverified.
    demo = "Demo dataset (simulated)"
    return [
        ("Central School Hall", "N12", 300, 120, "Step-free entrance, accessible toilets", "Water, beds, first aid", "Not provided", 1, demo),
        ("Hilltop Community Center", "N04", 200, 185, "Ramp access", "Water, generator", "Not provided", 1, demo),
        ("Eastfield Stadium Shelter", "N33", 800, 800, "Step-free, wide gates", "Beds, kitchen, medical post", "Not provided", 1, demo),
        ("Lakeview Sports Hall", "N20", 250, 40, "Step-free entrance", "Water, power, showers", "Not provided", 1, demo),
        ("North Ridge Relief Camp", "N03", 400, 90, "Partial (gravel paths)", "Tents, water", "Not provided", 1, demo),
        ("Pine Heights Hall", "N44", 150, 0, "Unknown", "Unknown", "Not provided", 0, ""),
    ]


def seed_incidents():
    return [("Flood", "High", "N31", "Rising water reported near Ferry Landing (sample)", "Active"),
            ("Wildfire", "Medium", "N04", "Brush fire near Hilltop (sample)", "Active"),
            ("Earthquake", "Low", "N22", "Minor structural damage reported (sample)", "Resolved"),
            ("Cyclone", "Medium", "N40", "Outer band expected, awaiting confirmation (sample)", "Under review")]


def load_osm_network(lat, lon, dist_m=1500):
    """OPTIONAL hook for real roads (needs `pip install osmnx` and internet). Returns the same
    (nodes, roads) shapes as build_demo_network. Not used by the default demo; shelters and
    incidents must be re-mapped to the new node ids before switching."""
    import osmnx as ox  # imported lazily so the demo runs without it
    G = ox.graph_from_point((lat, lon), dist=dist_m, network_type="drive").to_undirected()
    nodes = {str(n): {"id": str(n), "name": f"Node {n}", "lat": d["y"], "lon": d["x"]} for n, d in G.nodes(data=True)}
    roads, seen = [], set()
    for u, v, d in G.edges(data=True):
        eid = edge_id(str(u), str(v))
        if eid in seen or u == v:
            continue
        seen.add(eid)
        hw = d.get("highway", "residential")
        hw = hw[0] if isinstance(hw, list) else hw
        arterial = hw in ("primary", "secondary", "trunk")
        roads.append({"id": eid, "u": str(u), "v": str(v), "length_km": round(d.get("length", 100) / 1000, 3),
                      "speed_kmh": 50 if arterial else 30, "road_type": hw, "congestion": 0.0,
                      "name": str(d.get("name", hw))})
    return nodes, roads
