# SafeRoute AI - Disaster Evacuation Route Planning and Management

Educational prototype (not a certified emergency system). It does not replace emergency services or official
evacuation orders. All data bundled here is **synthetic sample data**; incident reports are **unverified**.

## Quick start
```bash
python -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python -m unittest discover -s tests -v                # algorithm + planner tests (no Streamlit needed)
streamlit run app.py
```
Responder (edit) access in the sidebar uses the demo PIN `demo`. Change it: `export SAFEROUTE_DEMO_PIN=yourpin`.
Optional: `SAFEROUTE_DB=path/to.db`, `SAFEROUTE_CONTACTS='{"Emergency services":"<your local number>"}'`.

## Project layout
| File | Role |
|---|---|
| app.py | Navigation, pages, session state |
| algorithms.py | Dijkstra (heapq), Bellman-Ford (+negative-cycle detection), heap-based k-shortest routes |
| graph_manager.py | NetworkX graph, hazard zones, closures, safety-aware non-negative edge costs |
| route_planner.py | Algorithm dispatch, alternatives and ranking, explanations, shelter ranking |
| map_utils.py | Folium map: layers, popups, legend, route overlays |
| database.py | SQLite: shelters, incidents, road status, route history |
| data_loader.py | Synthetic network/shelters/incidents + optional OSM loader hook (osmnx) |
| components.py, styles.css | Reusable UI and responsive dark-navy theme |

## How the pieces work together
1. **NetworkX** holds the road graph (nodes = intersections, edges = road segments with length, speed, congestion, hazard).
2. `graph_manager.adjacency()` turns it into a directed adjacency dict, **dropping closed roads** and computing a
   **non-negative** cost: `time * (1 + hazard_weight * hazard)` (or time / distance only, per objective).
3. **Dijkstra** settles nodes from a `heapq` min-heap (lazy deletion), so it is O((V+E) log V).
4. **Bellman-Ford** relaxes all edges V-1 times; one extra pass detects a reachable negative cycle, in which case no
   route is shown. Negative weights are rejected for physical costs (the Analytics "Algorithm lab" demonstrates both).
5. **Heap-based optimizer**: best-first search with priority = cost so far + exact remaining cost (reverse Dijkstra). Routes
   leave the heap cheapest-first, giving ranked alternatives; near-duplicates (>=70% shared roads) are filtered out.
6. Folium draws the result; Plotly compares algorithms, shelters and before/after scenarios.

## Deployment (Streamlit Community Cloud)
Push this folder to GitHub, create a new app at share.streamlit.io pointing to `app.py`, add secrets/env vars in the
app settings (never commit them). SQLite resets on redeploy there; use a hosted database for persistent real use.
Map tiles load from the internet (OpenStreetMap / CARTO); the demo network itself needs no paid API.

## Using real data later
- Roads: `data_loader.load_osm_network(lat, lon)` (needs `osmnx`) returns the same node/road structures; shelters and
  incidents must then be re-mapped to the new node ids. This hook is untested in this repo.
- Hazards, closures, shelter capacity: replace `database.py` readers with a verified official feed. Keep the rule that
  records without a documented source stay Unverified.

## Demo script for judges (about 5 minutes)
1. **Home**: state the safety framing (sample data, prototype). Click *Plan Evacuation Route*.
2. **Evacuation Map**: start N40 (South Basin), destination = nearest available shelter. Show the green route, blue/orange
   alternatives, red closed roads and the "why this route" text.
3. Switch algorithm Dijkstra -> Bellman-Ford -> Heap-based; then open **Analytics**: same cost, different execution time.
4. Change objective to *Fastest* and move the hazard slider to show shortest/fastest is not always safest.
5. **Disaster Simulation**: Flood, High, centre N22, 8 affected segments. Show the before/after route and chart.
   Increase closures until "no valid route" appears and read the warning aloud.
6. **Shelters / Incidents**: unlock responder access (PIN `demo`), mark a shelter Full, report a blocked road, and re-plan.
7. **Analytics -> Algorithm lab**: tick the negative-cycle box to show detection and rejection.

## Privacy and safety notes
Reports store a map node and short text only. "Share safety status" is a text preview, nothing is transmitted.
No algorithm here guarantees safety; always follow official instructions.
