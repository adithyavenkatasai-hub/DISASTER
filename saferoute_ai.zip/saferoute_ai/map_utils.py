"""Folium map construction. Everything drawn here comes from the demo graph, simulated hazard
zones or unverified reports; the legend says so."""
from __future__ import annotations
import html
import folium
from data_loader import CENTER

HAZARD_ICON = {"Flood": "🌊", "Earthquake": "🏚️", "Cyclone": "🌀", "Wildfire": "🔥", "Other": "⚠️"}
POI_ICON = {"hospital": "🏥", "fire": "🚒", "police": "🚓"}
STATUS_COLOR = {"Available": "#2ecc71", "Limited Capacity": "#ff9f1c", "Full": "#ff4d5e", "Unverified": "#9fb0cf"}
ZONE_COLOR = {"Low": "#ffd166", "Medium": "#ff9f1c", "High": "#ff4d5e"}


def _pin(emoji, bg="#0a1424", border="#1fd1b4", size=30):
    return folium.DivIcon(icon_size=(size, size), icon_anchor=(size // 2, size // 2),
                          html=f'<div style="width:{size}px;height:{size}px;border-radius:50%;background:{bg};'
                               f'border:2px solid {border};display:flex;align-items:center;justify-content:center;'
                               f'font-size:{size // 2}px;box-shadow:0 2px 6px rgba(0,0,0,.45)">{emoji}</div>')


def _latlon(rg, n):
    return [rg.nodes[n]["lat"], rg.nodes[n]["lon"]]


def _line(rg, path, **kw):
    return folium.PolyLine([_latlon(rg, n) for n in path], **kw)


LEGEND = """<details open style="position:fixed;bottom:10px;left:10px;z-index:9999;background:#0f1d36;color:#e8eefc;
font:12px/1.5 sans-serif;padding:8px 10px;border-radius:10px;max-width:200px;box-shadow:0 2px 8px rgba(0,0,0,.4)">
<summary style="cursor:pointer;font-weight:700">Legend</summary>
<div><span style="color:#2ecc71">&#9632;</span> Recommended route</div>
<div><span style="color:#3b8cff">&#9632;</span> Alternative 1 &nbsp;<span style="color:#ff9f1c">&#9632;</span> Alternative 2</div>
<div><span style="color:#ff4d5e">&#9632;</span> Closed / restricted road</div>
<div><span style="color:#ffb454">&#9711;</span> Hazard zone (sample)</div>
<div>&#127968; Shelter &nbsp;&#127973; Hospital</div>
<div style="color:#9fb0cf;margin-top:4px">Demo network &middot; simulated data</div></details>"""


def build_map(rg, closed, shelters, pois, incidents, zones, primary=None, alts=(), origin=None, dest=None,
              height_note=None):
    m = folium.Map(location=CENTER, zoom_start=14, tiles="OpenStreetMap", control_scale=True, prefer_canvas=True)
    folium.TileLayer("CartoDB positron", name="Light map").add_to(m)
    folium.TileLayer("CartoDB dark_matter", name="Dark map").add_to(m)

    roads = folium.FeatureGroup("Roads", show=True)
    blocked = folium.FeatureGroup("Closed / restricted roads", show=True)
    for u, v, d in rg.G.edges(data=True):
        pts = [_latlon(rg, u), _latlon(rg, v)]
        tip = f"{d['name']} ({d['road_type']}, {d['length_km']} km)"
        if d["id"] in closed:
            folium.PolyLine(pts, color="#ff4d5e", weight=6, dash_array="8 8", opacity=.95,
                            tooltip=f"CLOSED: {html.escape(tip)}").add_to(blocked)
        else:
            col = "#ff9f1c" if d["hazard"] >= 0.5 else "#6f86b3"
            folium.PolyLine(pts, color=col, weight=4 if d["road_type"] == "Arterial" else 3, opacity=.8,
                            tooltip=f"{html.escape(tip)} | hazard {d['hazard']}").add_to(roads)
    roads.add_to(m); blocked.add_to(m)

    nodes_fg = folium.FeatureGroup("Intersections", show=False)
    for n in rg.nodes.values():
        folium.CircleMarker([n["lat"], n["lon"]], radius=4, color="#1fd1b4", fill=True, fill_opacity=.9,
                            tooltip=f"{html.escape(n['name'])} ({n['id']})").add_to(nodes_fg)
    nodes_fg.add_to(m)

    hz = folium.FeatureGroup("Hazard zones (sample / simulated)", show=True)
    for z in zones:
        folium.Circle([z["lat"], z["lon"]], radius=z["radius_km"] * 1000, color=ZONE_COLOR[z["severity"]],
                      fill=True, fill_opacity=.12, weight=1.5,
                      tooltip=f"{z['type']} - {z['severity']} ({html.escape(z['source'])})").add_to(hz)
    for i in incidents:
        folium.Marker(_latlon(rg, i["node"]), icon=_pin(HAZARD_ICON.get(i["disaster_type"], "⚠️"), border="#ff4d5e"),
                      popup=folium.Popup(f"<b>{i['disaster_type']}</b> ({i['severity']})<br>{html.escape(i['description'])}"
                                         f"<br>Status: {i['status']}<br><i>Unverified / sample</i>", max_width=240)).add_to(hz)
    hz.add_to(m)

    sh = folium.FeatureGroup("Shelters & services", show=True)
    for s in shelters:
        folium.Marker(_latlon(rg, s["node"]), icon=_pin("🏠", border=STATUS_COLOR[s["status"]]),
                      popup=folium.Popup(f"<b>{html.escape(s['name'])}</b><br>Status: <b>{s['status']}</b><br>"
                                         f"Capacity {s['capacity']} | occupied {s['occupied']} | free {s['available']}<br>"
                                         f"Source: {html.escape(s['source'] or 'none (unverified)')}", max_width=260),
                      tooltip=s["name"]).add_to(sh)
    for p in pois:
        folium.Marker(_latlon(rg, p["node"]), icon=_pin(POI_ICON[p["kind"]], border="#3b8cff", size=26),
                      tooltip=f"{p['name']} (demo)").add_to(sh)
    sh.add_to(m)

    rt = folium.FeatureGroup("Routes", show=True)
    for a, col in zip(alts, ("#3b8cff", "#ff9f1c")):
        _line(rg, a["path"], color=col, weight=5, opacity=.85, dash_array="2 8",
              tooltip=f"{a['label']}: {a['distance_km']} km, {a['time_min']} min").add_to(rt)
    if primary:
        _line(rg, primary["path"], color="#2ecc71", weight=8, opacity=.95,
              tooltip=f"Recommended: {primary['distance_km']} km, {primary['time_min']} min").add_to(rt)
    rt.add_to(m)
    if origin:
        folium.Marker(_latlon(rg, origin), icon=_pin("📍", bg="#3b8cff", border="#fff", size=34), tooltip="Start").add_to(m)
    if dest:
        folium.Marker(_latlon(rg, dest), icon=_pin("🏁", bg="#2ecc71", border="#fff", size=34), tooltip="Destination").add_to(m)

    pts = [[n["lat"], n["lon"]] for n in rg.nodes.values()]
    m.fit_bounds([[min(p[0] for p in pts), min(p[1] for p in pts)], [max(p[0] for p in pts), max(p[1] for p in pts)]])
    folium.LayerControl(collapsed=True).add_to(m)
    m.get_root().html.add_child(folium.Element(LEGEND))
    return m
