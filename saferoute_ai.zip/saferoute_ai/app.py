"""SafeRoute AI - Disaster Evacuation Route Planning and Management (educational prototype).
Run with:  streamlit run app.py"""
from __future__ import annotations
import json
import os
from datetime import datetime

import pandas as pd
import plotly.express as px
import streamlit as st
from streamlit_folium import st_folium

import algorithms as alg
import components as ui
import data_loader as dl
import database as db
import graph_manager as gm
import map_utils as mu
import route_planner as rp

st.set_page_config(page_title="SafeRoute AI", page_icon="🛟", layout="wide", initial_sidebar_state="auto")
ui.inject_css()

NODES, ROADS, POIS = dl.build_demo_network()
ROAD_BY_ID = {r["id"]: r for r in ROADS}
db.init_db(ROADS)
ss = st.session_state
PAGES = ["Home", "Dashboard", "Evacuation Map", "Disaster Simulation", "Shelters",
         "Incidents & Roads", "Analytics", "Emergency Info"]
for k, v in {"page": "Home", "origin": "N40", "dest_mode": "Nearest available shelter", "dest_node": "N12",
             "algo": "Dijkstra", "objective": gm.OBJECTIVES[0], "hw": 3.0, "sim": None,
             "click_mode": "Off", "last_route_edges": None}.items():
    ss.setdefault(k, v)
# map clicks are applied BEFORE the widgets are created (Streamlit forbids changing a widget after it renders)
if ss.get("_pending_origin"):
    ss.origin = ss.pop("_pending_origin")
if ss.get("_pending_dest"):
    ss.dest_node, ss.dest_mode = ss.pop("_pending_dest"), "Choose a location"


def nlabel(n):
    return f"{NODES[n]['name']} ({n})"


def rlabel(rid):
    return f"{ROAD_BY_ID[rid]['name']} [{rid}]"


def goto(p):
    ss.page = p


# ---------------------------------------------------------------- sidebar
with st.sidebar:
    ui.md('<div class="sr-brand">🛟 SafeRoute AI<small>Evacuation route planning (prototype)</small></div>')
    st.radio("Navigate", PAGES, key="page", label_visibility="collapsed")
    with st.expander("Route settings", expanded=ss.page == "Evacuation Map"):
        st.selectbox("Start location", list(NODES), format_func=nlabel, key="origin")
        st.radio("Destination", ["Nearest available shelter", "Choose a location"], key="dest_mode")
        if ss.dest_mode == "Choose a location":
            st.selectbox("Destination location", list(NODES), format_func=nlabel, key="dest_node")
        st.selectbox("Algorithm", rp.ALGORITHMS, key="algo")
        st.selectbox("Route objective", gm.OBJECTIVES, key="objective")
        st.slider("Hazard avoidance weight", 0.0, 10.0, step=0.5, key="hw",
                  help="Higher values make the planner pay more to avoid hazardous roads.")
    with st.expander("Responder access (demo)"):
        pin = st.text_input("Demo PIN", type="password")
        ss.authorized = bool(pin) and pin == os.environ.get("SAFEROUTE_DEMO_PIN", "demo")
        st.caption("Unlocks editing of shelters, incidents and roads. Set SAFEROUTE_DEMO_PIN to change it.")
        if ss.authorized:
            st.success("Demo responder access on")
    st.caption(ui.DISCLAIMER)


# ---------------------------------------------------------------- shared context
def build_context(use_sim=True):
    rg = gm.RoadGraph(NODES, ROADS)
    zones = [gm.make_zone(NODES[i["node"]], i["disaster_type"], i["severity"], "reported incident",
                          "unverified report" if not i["is_sample"] else "sample incident")
             for i in db.active_incidents()]
    closed = set(db.closed_road_ids())
    sim = ss.sim if use_sim else None
    if sim:
        zones.append(sim["zone"])
        closed |= set(sim["closed"])
    rg.apply_zones(zones)
    return rg, frozenset(closed), zones, sim


def current_plan(rg, closed):
    ranked = []
    if ss.dest_mode == "Nearest available shelter":
        ranked = rp.rank_shelters(rg, ss.origin, db.list_shelters(), ss.objective, ss.hw, closed)
        if not ranked:
            return {"status": "no_route", "message": "No Available or Limited-capacity shelter is reachable. "
                    "Contact local emergency authorities."}, None, ranked
        dest = ranked[0]["node"]
    else:
        dest = ss.dest_node
    return rp.plan_route(rg, ss.origin, dest, ss.algo, ss.objective, ss.hw, closed), dest, ranked


def dest_name(dest):
    for s in db.list_shelters():
        if s["node"] == dest:
            return s["name"]
    return NODES[dest]["name"]


def style(fig, h=320):
    fig.update_layout(template="plotly_dark", paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
                      height=h, margin=dict(l=8, r=8, t=40, b=8), legend=dict(orientation="h", y=-0.2),
                      font=dict(color="#e8eefc"))
    return fig


def sim_banner(sim):
    if sim:
        ui.banner(f"<b>SIMULATION ACTIVE</b>: {sim['params']['dtype']} ({sim['params']['severity']}) near "
                  f"{h(NODES[sim['params']['node']]['name'])}. Results are simulated, not real emergency information.", "sim")


h = ui.h
RG, CLOSED, ZONES, SIM = build_context()


# ---------------------------------------------------------------- pages
def page_home():
    incs, shelters = db.active_incidents(), db.list_shelters()
    ui.md('<div class="sr-hero"><h1>SafeRoute AI</h1><p>Plan evacuation routes that avoid closed roads and known hazards. '
          'Compare Dijkstra, Bellman-Ford and heap-based route optimisation, simulate disasters and manage shelters '
          'and incident reports.</p></div>')
    st.button("Plan Evacuation Route", key="home_plan", on_click=goto, args=("Evacuation Map",))
    ui.banner("Demonstration data: the network, shelters and incidents are synthetic samples, not live emergency data.", "warn")
    c = st.columns(4)
    with c[0]: ui.metric("Active incidents", len(incs), "sample / unverified", "danger")
    with c[1]: ui.metric("Available shelters", sum(s["status"] in rp.STATUS_USABLE for s in shelters), f"of {len(shelters)} records", "ok")
    with c[2]: ui.metric("Affected locations", len({i["node"] for i in incs}), "from active reports", "warn")
    with c[3]: ui.metric("Blocked roads", len(db.closed_road_ids()), "restricted segments", "danger")
    st.subheader("Quick access")
    q = st.columns(4)
    for col, (label, page) in zip(q, [("🧭 Route planning", "Evacuation Map"), ("🧪 Simulate disaster", "Disaster Simulation"),
                                      ("🏠 Shelters", "Shelters"), ("📝 Reports", "Incidents & Roads")]):
        col.button(label, key=f"q_{page}", on_click=goto, args=(page,))


def page_dashboard():
    incs = db.list_incidents()
    active = [i for i in incs if i["status"] != "Resolved"]
    shelters = db.list_shelters()
    rank = {"Low": 1, "Medium": 2, "High": 3}
    risk = max((i["severity"] for i in active), key=rank.get, default="Low").upper()
    ui.md(f'<div class="sr-bar"><b class="t">Incident Tracking Center</b><span>{datetime.now():%d %b %Y %H:%M}</span>'
          f'<span>Overall risk level <b class="sr-risk-{risk}">{risk}</b></span>'
          f'<span>Last report: {h(incs[0]["created_at"]) if incs else "none"}</span></div>')
    ui.banner("Sample / simulated information only. Not live emergency data; reports are unverified.", "warn")
    sim_banner(SIM)
    c1, c2, c3 = st.columns([1.1, 2, 1.2])
    with c1:
        ui.md(f'<div class="sr-panel"><b>📍 Demo region</b><div class="sr-msub">{h(dl.DEMO_LABEL)}</div><br>'
              f'<div style="display:flex;justify-content:space-between"><div><div class="sr-msub">Reports</div><b>{len(incs)}</b></div>'
              f'<div><div class="sr-msub">Active</div><b>{len(active)}</b></div>'
              f'<div><div class="sr-msub">Resolved</div><b>{len(incs) - len(active)}</b></div></div></div>')
        g = st.columns(2)
        for col, s in zip(g, [s for s in shelters if s["verified"]][:2]):
            pct = 100 * s["occupied"] / s["capacity"]
            with col:
                ui.gauge(pct, s["name"], f"{s['occupied']} of {s['capacity']}", "#ff9f1c" if pct > 70 else "#1fd1b4")
    with c2:
        rg, closed, zones, _ = RG, CLOSED, ZONES, None
        m = mu.build_map(rg, closed, shelters, POIS, active, zones)
        st_folium(m, height=400, use_container_width=True, returned_objects=[], key="dash_map")
    with c3:
        occ, cap = sum(s["occupied"] for s in shelters if s["verified"]), sum(s["capacity"] for s in shelters if s["verified"])
        ui.gauge(100 * occ / max(cap, 1), "People in verified shelters", f"{occ} of {cap} spaces (sample)")
        st.markdown("**Notifications**")
        for i in incs[:4]:
            ui.notification(i["severity"], f"{i['disaster_type']}: {i['description']}", f"{i['status']} | {i['updated_at']}")
    c = st.columns(4)
    with c[0]: ui.metric("Active incidents", len(active), "", "danger")
    with c[1]: ui.metric("Available shelters", sum(s["status"] in rp.STATUS_USABLE for s in shelters), "", "ok")
    with c[2]: ui.metric("Affected locations", len({i["node"] for i in active}), "", "warn")
    with c[3]: ui.metric("Blocked roads", len(CLOSED), "incl. simulated" if SIM else "", "danger")
    d1, d2, d3 = st.columns([2, 1.2, 1.2])
    with d1:
        if incs:
            df = pd.DataFrame(incs).groupby("disaster_type").size().reset_index(name="Reports")
            st.plotly_chart(style(px.bar(df, x="disaster_type", y="Reports", title="Incident categories",
                                         color_discrete_sequence=["#1fd1b4"]), 260), use_container_width=True)
    with d2:
        st.markdown("**Incident risk level**")
        for sev, col in (("High", "#ff4d5e"), ("Medium", "#ff9f1c"), ("Low", "#1fd1b4")):
            ui.md(f'<div class="sr-note" style="border-left-color:{col}">{sum(i["severity"] == sev for i in active)} {sev}</div>')
    with d3:
        st.button("🚨 Emergency info", key="act_emergency", on_click=goto, args=("Emergency Info",))
        st.button("📝 New report", key="act_report", on_click=goto, args=("Incidents & Roads",))
        st.button("🧭 Plan route", key="act_route", on_click=goto, args=("Evacuation Map",))
    st.subheader("Route-planning activity")
    hist = db.route_history(8)
    if hist:
        st.dataframe(pd.DataFrame(hist).drop(columns="id"), use_container_width=True, hide_index=True)
    else:
        st.info("No routes logged yet. Plan a route and select 'Log this plan' to see activity here.")


def route_panel(plan, dest, ranked):
    if plan["status"] != "ok":
        ui.banner(f"<b>{h(plan['message'])}</b><br>Contact local emergency authorities; no route is invented.", "danger")
        return
    p = plan["primary"]
    ui.route_card(p, dest_name(dest))
    a, b = st.columns(2)
    with a: ui.metric("Distance", f"{p['distance_km']} km"); ui.metric("Road segments", p["segments"])
    with b: ui.metric("Est. time", f"{p['time_min']:.0f} min", "sample speeds, not live traffic")
    with b: ui.metric("Hazard exposure", f"{p['exposure']}/100", f"{p['hazard_segments']} hazardous segments", "warn" if p["exposure"] else "ok")
    st.caption(f"{p['algorithm']} ran in {p['exec_ms']} ms")
    st.markdown("**Why this route**")
    st.write(p["explanation"])
    if plan["alternatives"]:
        rows = [{"Route": r["label"], "km": r["distance_km"], "min": r["time_min"], "Exposure": r["exposure"],
                 "Segments": r["segments"]} for r in [p] + plan["alternatives"]]
        st.dataframe(pd.DataFrame(rows), use_container_width=True, hide_index=True)
    else:
        st.info("No meaningfully different alternative route exists with the current closures.")
    with st.expander("Share safety status (preview only)"):
        st.code(rp.share_text(dest_name(dest), p), language=None)
        st.caption("Nothing is sent and no GPS location is stored. Copy this text to message your contacts.")
    if st.button("Log this plan", key="log_plan"):
        db.log_route(ss.origin, dest, p, bool(SIM))
        st.success("Logged in route history.")


def page_map():
    st.title("Evacuation map")
    sim_banner(SIM)
    plan, dest, ranked = current_plan(RG, CLOSED)
    prev = ss.last_route_edges
    if prev and set(prev) & CLOSED:
        ui.banner("The previously planned route now uses a closed road. It was recalculated below.", "warn")
    ss.last_route_edges = plan["primary"]["edge_ids"] if plan["status"] == "ok" else None
    ui.md('<div class="sr-panel"><b>Find the best evacuation route</b><div class="sr-msub">Use the sidebar to change the start, '
          'destination, algorithm and objective, or click the map.</div></div>')
    st.radio("Map click sets", ["Off", "Set start", "Set destination"], horizontal=True, key="click_mode")
    left, right = st.columns([2.3, 1.2])
    with left:
        m = mu.build_map(RG, CLOSED, db.list_shelters(), POIS, db.active_incidents(), ZONES,
                         plan.get("primary"), plan.get("alternatives", []), ss.origin, dest)
        out = st_folium(m, height=560, use_container_width=True, returned_objects=["last_clicked"], key="main_map")
        click = (out or {}).get("last_clicked")
        if click and ss.click_mode != "Off":
            sig = (round(click["lat"], 6), round(click["lng"], 6))
            if ss.get("_last_click") != sig:
                ss._last_click = sig
                node = RG.nearest_node(click["lat"], click["lng"])
                ss["_pending_origin" if ss.click_mode == "Set start" else "_pending_dest"] = node
                st.rerun()
    with right:
        route_panel(plan, dest, ranked)


def page_sim():
    st.title("Disaster simulation")
    ui.banner("Simulation results are hypothetical and must not be treated as real-world emergency information.", "sim")
    with st.form("sim_form"):
        a, b = st.columns(2)
        dtype = a.selectbox("Disaster type", db.DISASTERS)
        sev = b.selectbox("Hazard severity", db.SEVERITIES, index=1)
        node = a.selectbox("Hazard centre", list(NODES), format_func=nlabel, index=list(NODES).index("N22"))
        n_aff = b.slider("Affected road segments (auto-closed, most exposed first)", 0, 15, 5)
        manual = st.multiselect("Extra blocked roads", list(ROAD_BY_ID), format_func=rlabel)
        run = st.form_submit_button("Run simulation")
    if run:
        z = gm.make_zone(NODES[node], dtype, sev, "simulated", "simulation")
        rg2 = gm.RoadGraph(NODES, ROADS)
        rg2.apply_zones([z])
        closed = list(dict.fromkeys(rg2.hazard_ranking()[:n_aff] + manual))
        ss.sim = {"zone": z, "closed": closed, "params": {"dtype": dtype, "severity": sev, "node": node}}
        st.rerun()
    if not ss.sim:
        st.info("No simulation yet. Choose a scenario and run it to see how the route changes.")
        return
    if st.button("Clear simulation", key="clear_sim"):
        ss.sim = None
        st.rerun()
    rg0, c0, z0, _ = build_context(False)
    rg1, c1, z1, _ = build_context(True)
    before, d0, _ = current_plan(rg0, c0)
    after, d1, _ = current_plan(rg1, c1)
    sim_banner(ss.sim)
    st.write(f"**{len(ss.sim['closed'])} road segments closed by the simulation.**")
    if before["status"] == "ok" and set(before["primary"]["edge_ids"]) & set(ss.sim["closed"]):
        ui.banner("The route planned before the disaster is now blocked. A new route was calculated.", "warn")
    if after["status"] != "ok":
        ui.banner(f"<b>{h(after['message'])}</b> Consult local emergency authorities.", "danger")
    m = mu.build_map(rg1, c1, db.list_shelters(), POIS, db.active_incidents(), z1,
                     after.get("primary"), [dict(before["primary"], label="Before simulation")] if before["status"] == "ok" else [],
                     ss.origin, d1)
    st_folium(m, height=480, use_container_width=True, returned_objects=[], key="sim_map")
    st.caption("Green = route after simulation. Blue dotted = route before simulation.")
    if before["status"] == "ok" and after["status"] == "ok":
        rows = []
        for name, r in (("Before", before["primary"]), ("After", after["primary"])):
            rows += [{"Scenario": name, "Metric": "Distance (km)", "Value": r["distance_km"]},
                     {"Scenario": name, "Metric": "Time (min)", "Value": r["time_min"]},
                     {"Scenario": name, "Metric": "Hazard exposure", "Value": r["exposure"]}]
        st.plotly_chart(style(px.bar(pd.DataFrame(rows), x="Metric", y="Value", color="Scenario", barmode="group",
                                     title="Route before vs after (simulated)",
                                     color_discrete_map={"Before": "#3b8cff", "After": "#2ecc71"})), use_container_width=True)
        ss.sim_cmp = rows


def page_shelters():
    st.title("Emergency shelters")
    shelters = db.list_shelters()
    adj = RG.adjacency("Shortest distance", 0, CLOSED)
    r = alg.dijkstra(adj, ss.origin)
    icon = {"Available": "🟢", "Limited Capacity": "🟠", "Full": "🔴", "Unverified": "⚪"}
    rows = []
    for s in shelters:
        dist = RG.path_metrics(alg.reconstruct_path(r.prev, ss.origin, s["node"]), CLOSED)["distance_km"] if s["node"] in r.dist else None
        rows.append({"Shelter": s["name"], "Status": f"{icon[s['status']]} {s['status']}", "Location": nlabel(s["node"]),
                     "Capacity": s["capacity"], "Occupied": s["occupied"], "Available": s["available"],
                     "Distance (km)": dist if dist is not None else "No open route", "Accessibility": s["accessibility"],
                     "Facilities": s["facilities"], "Contact": s["contact"], "Source": s["source"] or "None"})
    ui.banner(f"Distances are road distances from <b>{h(nlabel(ss.origin))}</b>. Shelters without a documented source stay Unverified.", "info")
    st.dataframe(pd.DataFrame(rows), use_container_width=True, hide_index=True)
    st.subheader("Manage shelters")
    if not ss.authorized:
        st.info("Unlock responder access in the sidebar (demo) to add, update or remove shelters.")
        return
    tabs = st.tabs(["Add", "Update", "Remove"])
    def fields(prefix, s=None):
        s = s or {}
        d = {"name": st.text_input("Name", s.get("name", ""), key=prefix + "n"),
             "node": st.selectbox("Location", list(NODES), format_func=nlabel, index=list(NODES).index(s.get("node", "N00")), key=prefix + "l"),
             "capacity": st.number_input("Capacity", 1, 100000, int(s.get("capacity", 100)), key=prefix + "c"),
             "occupied": st.number_input("Occupied", 0, 100000, int(s.get("occupied", 0)), key=prefix + "o"),
             "accessibility": st.text_input("Accessibility", s.get("accessibility", ""), key=prefix + "a"),
             "facilities": st.text_input("Facilities", s.get("facilities", ""), key=prefix + "f"),
             "contact": st.text_input("Contact (optional)", "" if s.get("contact") in (None, "Not provided") else s.get("contact"), key=prefix + "k"),
             "source": st.text_input("Verification source (required to mark verified)", s.get("source", ""), key=prefix + "s"),
             "verified": st.checkbox("Mark as verified", bool(s.get("verified")), key=prefix + "v")}
        return d
    def save(d, sid=None):
        try:
            ok = db.save_shelter(d, sid)
            st.success("Saved." + ("" if ok or not d["verified"] else " Stored as Unverified: no verification source given."))
            st.rerun()
        except (ValueError, TypeError) as e:
            st.error(str(e))
    with tabs[0]:
        with st.form("add_sh"):
            d = fields("add")
            if st.form_submit_button("Add shelter"):
                save(d)
    with tabs[1]:
        sel = st.selectbox("Shelter", shelters, format_func=lambda s: s["name"], key="upd_sel")
        with st.form(f"upd_{sel['id']}"):
            d = fields(f"upd{sel['id']}", sel)
            if st.form_submit_button("Update shelter"):
                save(d, sel["id"])
    with tabs[2]:
        sel = st.selectbox("Shelter to remove", shelters, format_func=lambda s: s["name"], key="del_sel")
        if st.button("Remove shelter", key="del_btn"):
            db.delete_shelter(sel["id"])
            st.success("Removed.")
            st.rerun()


def page_incidents():
    st.title("Incidents and roads")
    ui.banner("Reports are <b>unverified</b> until confirmed by an official source. Closures from reports are still "
              "excluded from routes as a precaution. Reports store only a map location and text, never names or phone numbers.", "warn")
    if ss.authorized:
        with st.form("rep"):
            a, b = st.columns(2)
            dtype = a.selectbox("Disaster type", db.DISASTERS)
            sev = b.selectbox("Severity", db.SEVERITIES, index=1)
            node = a.selectbox("Affected location", list(NODES), format_func=nlabel)
            roads = b.multiselect("Blocked or damaged roads", list(ROAD_BY_ID), format_func=rlabel)
            desc = st.text_area("Description (no personal details)", max_chars=500)
            if st.form_submit_button("Submit report"):
                if len(desc.strip()) < 5:
                    st.error("Add a short description (at least 5 characters).")
                else:
                    iid = db.add_incident(dtype, sev, node, desc, roads)
                    st.success(f"Report #{iid} saved as Reported (unverified).")
                    st.rerun()
    else:
        st.info("Unlock responder access in the sidebar (demo) to submit or update reports. History is visible to everyone.")
    incs = db.list_incidents()
    st.subheader("Incident history")
    df = pd.DataFrame(incs)
    if df.empty:
        st.info("No incidents recorded.")
    else:
        df["location"] = df["node"].map(lambda n: NODES[n]["name"])
        df["verified"] = df["verified"].map({0: "Unverified", 1: "Verified"})
        df["origin"] = df["is_sample"].map({1: "Sample data", 0: "User report"})
        st.dataframe(df[["id", "disaster_type", "severity", "location", "description", "status", "verified", "origin", "created_at", "updated_at"]],
                     use_container_width=True, hide_index=True)
    if ss.authorized and incs:
        a, b = st.columns(2)
        sel = a.selectbox("Incident", incs, format_func=lambda i: f"#{i['id']} {i['disaster_type']} - {i['status']}")
        new = b.selectbox("New status", db.STATUSES, index=db.STATUSES.index(sel["status"]))
        if st.button("Update status", key="upd_status"):
            db.update_incident_status(sel["id"], new)
            st.success("Status updated.")
            st.rerun()
    st.subheader("Closed roads")
    closed = db.closed_road_details()
    if closed:
        st.dataframe(pd.DataFrame([{"Road": rlabel(c["road_id"]), "Reason": c["reason"], "Since": c["updated_at"]} for c in closed]),
                     use_container_width=True, hide_index=True)
    else:
        st.info("No closed roads recorded.")
    if ss.authorized:
        a, b = st.columns(2)
        if closed:
            rid = a.selectbox("Mark road as reopened", [c["road_id"] for c in closed], format_func=rlabel)
            if a.button("Reopen road", key="reopen"):
                db.reopen_road(rid); st.success("Road reopened."); st.rerun()
        rid2 = b.selectbox("Restrict a road", [r for r in ROAD_BY_ID if r not in db.closed_road_ids()], format_func=rlabel)
        if b.button("Close road", key="close"):
            db.close_road(rid2); st.success("Road restricted."); st.rerun()


def page_analytics():
    st.title("Route comparison and analytics")
    sim_banner(SIM)
    plan, dest, _ = current_plan(RG, CLOSED)
    if plan["status"] != "ok":
        ui.banner(h(plan["message"]), "danger")
    else:
        rows = [{"Algorithm": a, "Distance (km)": r["distance_km"], "Time (min)": r["time_min"], "Exposure": r["exposure"],
                 "Segments": r["segments"], "Execution (ms)": r["exec_ms"], "Cost": r["cost"]}
                for a, r in plan["comparison"].items() if r]
        df = pd.DataFrame(rows)
        c = st.columns(3)
        with c[0]: ui.metric("Best distance", f"{df['Distance (km)'].min()} km")
        with c[1]: ui.metric("Best time", f"{df['Time (min)'].min():.0f} min")
        with c[2]: ui.metric("Fastest algorithm", df.loc[df["Execution (ms)"].idxmin(), "Algorithm"], f"{df['Execution (ms)'].min()} ms", "teal")
        st.caption("All three algorithms minimise the same non-negative cost, so they normally return the same route; "
                   "they differ in execution time. Times are sample estimates, not live traffic.")
        a, b = st.columns(2)
        pal = ["#1fd1b4", "#3b8cff", "#ff9f1c"]
        a.plotly_chart(style(px.bar(df, x="Algorithm", y="Distance (km)", color="Algorithm", title="Distance", color_discrete_sequence=pal)), use_container_width=True)
        b.plotly_chart(style(px.bar(df, x="Algorithm", y="Time (min)", color="Algorithm", title="Estimated travel time", color_discrete_sequence=pal)), use_container_width=True)
        a.plotly_chart(style(px.bar(df, x="Algorithm", y="Execution (ms)", color="Algorithm", title="Execution time", color_discrete_sequence=pal)), use_container_width=True)
        n_db, n_sim = len(db.closed_road_ids()), len(ss.sim["closed"]) if ss.sim else 0
        b.plotly_chart(style(px.bar(pd.DataFrame({"Source": ["Reports / restrictions", "Simulation"], "Roads": [n_db, n_sim]}),
                                    x="Source", y="Roads", title="Affected roads", color_discrete_sequence=["#ff4d5e"])), use_container_width=True)
    sh = pd.DataFrame(db.list_shelters())
    sh_long = pd.concat([sh.assign(Type="Occupied", Spaces=sh["occupied"]), sh.assign(Type="Available", Spaces=sh["available"])])
    st.plotly_chart(style(px.bar(sh_long, x="name", y="Spaces", color="Type", barmode="stack", title="Shelter availability",
                                 color_discrete_map={"Occupied": "#ff9f1c", "Available": "#2ecc71"}), 340), use_container_width=True)
    if ss.get("sim") and ss.get("sim_cmp"):
        st.plotly_chart(style(px.bar(pd.DataFrame(ss.sim_cmp), x="Metric", y="Value", color="Scenario", barmode="group",
                                     title="Before vs after simulated disaster")), use_container_width=True)
    with st.expander("Algorithm lab: Bellman-Ford and negative weights"):
        st.write("Evacuation costs are never negative. This lab shows why Bellman-Ford is still useful: it handles "
                 "negative edges and detects negative cycles, which can never form a valid route.")
        cyc = st.checkbox("Add a negative cycle (B->C -3, C->B +1)")
        edges = [("A", "B", 4), ("A", "C", 5), ("C", "B", -3), ("B", "D", 2)]
        edges = [e for e in edges if e[:2] != ("C", "B")] + ([("B", "C", -3), ("C", "B", 1)] if cyc else [("C", "B", -3)])
        st.dataframe(pd.DataFrame(edges, columns=["from", "to", "weight"]), hide_index=True)
        res = alg.bellman_ford("ABCD", edges, "A")
        if res.negative_cycle:
            ui.banner(f"Negative cycle through {', '.join(res.cycle_nodes)}: shortest paths are undefined. No route is shown.", "danger")
        else:
            st.success(f"Shortest distances from A: {res.dist}")
        try:
            alg.dijkstra({u: [(v, w) for x, v, w in edges if x == u] for u in "ABCD"}, "A")
        except alg.NegativeWeightError as e:
            st.warning(f"Dijkstra refuses this graph: {e}")


def page_info():
    st.title("Emergency information")
    ui.banner("This prototype does not replace emergency services or official evacuation orders. Always follow "
              "instructions from your local authorities.", "danger")
    a, b = st.columns(2)
    with a:
        st.subheader("Be prepared")
        st.markdown("- Know your local evacuation zones and nearest official shelters.\n- Keep a go-bag: water, food, medicines, "
                    "documents, torch, charger, first-aid kit.\n- Agree a family meeting point and an out-of-area contact.\n"
                    "- Keep fuel or charge above half during warning periods.")
        st.subheader("When an alert is issued")
        st.markdown("- Follow official alerts (national weather, civil-defence and local government channels).\n"
                    "- Leave early when told to; do not wait for conditions to worsen.\n- Never drive through floodwater or "
                    "around barriers.\n- Help neighbours who need assistance, if it is safe.")
    with b:
        st.subheader("Emergency contacts")
        default = json.loads(os.environ.get("SAFEROUTE_CONTACTS", "{}") or "{}")
        for label in ("Emergency services", "Local disaster agency", "Nearest hospital"):
            ss.setdefault(f"c_{label}", default.get(label, ""))
            st.text_input(label, key=f"c_{label}", placeholder="Not configured for this deployment")
        st.caption("No official numbers are bundled. Set SAFEROUTE_CONTACTS (JSON) or fill them in for your location.")


{"Home": page_home, "Dashboard": page_dashboard, "Evacuation Map": page_map, "Disaster Simulation": page_sim,
 "Shelters": page_shelters, "Incidents & Roads": page_incidents, "Analytics": page_analytics,
 "Emergency Info": page_info}[ss.page]()
st.markdown("---")
st.caption(ui.DISCLAIMER)
