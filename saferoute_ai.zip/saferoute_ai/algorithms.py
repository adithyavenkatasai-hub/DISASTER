"""Core shortest-path algorithms for SafeRoute AI (pure Python, no UI deps).

Graph format used everywhere: adjacency dict  {node: [(neighbour, weight), ...]}.
Edge costs used for real evacuation routing MUST be non-negative; Bellman-Ford is
included for general graphs and to demonstrate negative-cycle detection.
"""
from __future__ import annotations
import heapq
import math
from dataclasses import dataclass, field

INF = math.inf


class NegativeWeightError(ValueError):
    """Raised when a negative weight is used where it is physically meaningless."""


class NegativeCycleError(ValueError):
    """Raised when a reachable negative-weight cycle makes shortest paths undefined."""


@dataclass
class SearchResult:
    dist: dict
    prev: dict
    nodes_settled: int = 0
    negative_cycle: bool = False
    cycle_nodes: list = field(default_factory=list)


def validate_non_negative(adj):
    """Reject negative weights (distance / travel time can never be negative)."""
    for u, nbrs in adj.items():
        for v, w in nbrs:
            if w < 0:
                raise NegativeWeightError(
                    f"Negative weight {w} on {u}->{v}: not valid for distance or travel time.")


def reconstruct_path(prev, source, target):
    """Walk predecessor links back from target. Returns [] if unreachable."""
    if target != source and target not in prev:
        return []
    path, node, guard = [target], target, len(prev) + 2
    while node != source and guard > 0:
        node = prev.get(node)
        if node is None:
            return []
        path.append(node)
        guard -= 1
    return path[::-1] if path[-1] == source else []


def dijkstra(adj, source, target=None) -> SearchResult:
    """Dijkstra with a binary-heap priority queue (heapq). O((V+E) log V).

    Stops early when `target` is settled. Stale heap entries are skipped
    (lazy deletion) instead of using decrease-key.
    """
    validate_non_negative(adj)
    dist, prev, done = {source: 0.0}, {}, set()
    heap = [(0.0, source)]
    while heap:
        d, u = heapq.heappop(heap)
        if u in done:
            continue
        done.add(u)
        if u == target:
            break
        for v, w in adj.get(u, ()):
            nd = d + w
            if nd < dist.get(v, INF):
                dist[v], prev[v] = nd, u
                heapq.heappush(heap, (nd, v))
    return SearchResult(dist, prev, len(done))


def bellman_ford(nodes, edges, source) -> SearchResult:
    """Bellman-Ford over directed edges [(u, v, w)]. O(V*E).

    Supports negative weights. After V-1 relaxation rounds, any edge that can
    still be relaxed from a reachable node proves a reachable negative cycle;
    the cycle is recovered by walking predecessor links.
    """
    nodes = list(nodes)
    dist = {n: INF for n in nodes}
    prev = {}
    dist[source] = 0.0
    for _ in range(len(nodes) - 1):
        changed = False
        for u, v, w in edges:
            if dist[u] != INF and dist[u] + w < dist[v]:
                dist[v], prev[v] = dist[u] + w, u
                changed = True
        if not changed:
            break
    for u, v, w in edges:
        if dist[u] != INF and dist[u] + w < dist[v]:
            prev[v] = u
            x = v
            for _ in range(len(nodes)):      # step into the cycle
                x = prev[x]
            cycle, y = [x], prev[x]
            while y != x:
                cycle.append(y)
                y = prev[y]
            return SearchResult(dist, prev, len(nodes), True, cycle[::-1])
    return SearchResult({k: v for k, v in dist.items() if v != INF}, prev, len(nodes))


def adj_to_edges(adj):
    return [(u, v, w) for u, nbrs in adj.items() for v, w in nbrs]


def shortest_path_bf(adj, source, target):
    """Bellman-Ford route on an adjacency dict. Refuses routes tainted by a negative cycle
    and negative physical weights (callers pass non-negative evacuation costs)."""
    validate_non_negative(adj)  # evacuation costs are physical: reject negatives
    nodes = set(adj) | {v for n in adj.values() for v, _ in n} | {source, target}
    res = bellman_ford(nodes, adj_to_edges(adj), source)
    if res.negative_cycle:
        raise NegativeCycleError(f"Reachable negative cycle: {res.cycle_nodes}")
    path = reconstruct_path(res.prev, source, target)
    return path, res.dist.get(target, INF), res


def reverse_adj(adj):
    rev = {}
    for u, nbrs in adj.items():
        rev.setdefault(u, [])
        for v, w in nbrs:
            rev.setdefault(v, []).append((u, w))
    return rev


def k_shortest_paths(adj, source, target, k=5, max_expansions=50000):
    """Heap-based best-first search returning up to k loop-free routes, cheapest first.

    Priority = cost so far + exact remaining cost to target (from a reverse
    Dijkstra). That heuristic is admissible, so complete routes leave the heap
    in non-decreasing cost order.
    """
    validate_non_negative(adj)
    h = dijkstra(reverse_adj(adj), target).dist
    if source not in h:
        return []
    heap, results, expansions = [(h[source], 0.0, [source])], [], 0
    while heap and len(results) < k and expansions < max_expansions:
        _, g, path = heapq.heappop(heap)
        u = path[-1]
        if u == target:
            results.append((g, path))
            continue
        expansions += 1
        for v, w in adj.get(u, ()):
            if v not in path and v in h:
                heapq.heappush(heap, (g + w + h[v], g + w, path + [v]))
    return results
