"""SQLite persistence: shelters, incidents, road status, route history.
Privacy: reports store a map node (coarse location) and free text only; no names, phones or GPS traces."""
from __future__ import annotations
import os
import sqlite3
from datetime import datetime
from data_loader import seed_shelters, seed_incidents, edge_id

DB_PATH = os.environ.get("SAFEROUTE_DB", "saferoute.db")
STATUSES = ["Reported", "Under review", "Active", "Resolved"]
DISASTERS = ["Flood", "Earthquake", "Cyclone", "Wildfire", "Other"]
SEVERITIES = ["Low", "Medium", "High"]


def now():
    return datetime.now().strftime("%Y-%m-%d %H:%M")


def conn():
    c = sqlite3.connect(DB_PATH)
    c.row_factory = sqlite3.Row
    return c


def shelter_status(capacity, occupied, verified):
    if not verified:
        return "Unverified"
    if occupied >= capacity:
        return "Full"
    return "Limited Capacity" if (capacity - occupied) / capacity < 0.2 else "Available"


def init_db(roads):
    with conn() as c:
        c.executescript("""
        CREATE TABLE IF NOT EXISTS shelters(id INTEGER PRIMARY KEY, name TEXT, node TEXT, capacity INT, occupied INT,
            accessibility TEXT, facilities TEXT, contact TEXT, verified INT, source TEXT, updated_at TEXT);
        CREATE TABLE IF NOT EXISTS incidents(id INTEGER PRIMARY KEY, disaster_type TEXT, severity TEXT, node TEXT,
            description TEXT, status TEXT, verified INT DEFAULT 0, is_sample INT DEFAULT 0, created_at TEXT, updated_at TEXT);
        CREATE TABLE IF NOT EXISTS road_status(road_id TEXT PRIMARY KEY, status TEXT, reason TEXT, updated_at TEXT);
        CREATE TABLE IF NOT EXISTS route_history(id INTEGER PRIMARY KEY, created_at TEXT, origin TEXT, destination TEXT,
            algorithm TEXT, distance_km REAL, time_min REAL, exposure REAL, simulated INT);
        """)
        if c.execute("SELECT COUNT(*) FROM shelters").fetchone()[0] == 0:
            for s in seed_shelters():
                c.execute("INSERT INTO shelters(name,node,capacity,occupied,accessibility,facilities,contact,verified,source,updated_at)"
                          " VALUES(?,?,?,?,?,?,?,?,?,?)", (*s, now()))
            for t, sev, node, desc, st in seed_incidents():
                c.execute("INSERT INTO incidents(disaster_type,severity,node,description,status,is_sample,created_at,updated_at)"
                          " VALUES(?,?,?,?,?,1,?,?)", (t, sev, node, desc, st, now(), now()))
            for r in roads:                       # two sample closures next to the sample flood
                if "N31" in (r["u"], r["v"]) and c.execute("SELECT COUNT(*) FROM road_status").fetchone()[0] < 2:
                    c.execute("INSERT INTO road_status VALUES(?,?,?,?)", (r["id"], "closed", "Sample flood closure", now()))


# ---- shelters ----
def list_shelters():
    with conn() as c:
        rows = [dict(r) for r in c.execute("SELECT * FROM shelters ORDER BY name")]
    for r in rows:
        r["available"] = max(0, r["capacity"] - r["occupied"])
        r["status"] = shelter_status(r["capacity"], r["occupied"], r["verified"])
    return rows


def save_shelter(data, shelter_id=None):
    """Validates input. A shelter can only be 'verified' if a source is documented."""
    name = (data.get("name") or "").strip()
    if not name:
        raise ValueError("Shelter name is required.")
    cap, occ = int(data["capacity"]), int(data["occupied"])
    if cap <= 0 or occ < 0 or occ > cap:
        raise ValueError("Capacity must be positive and occupied spaces must be between 0 and capacity.")
    source = (data.get("source") or "").strip()
    verified = 1 if (data.get("verified") and source) else 0
    vals = (name, data["node"], cap, occ, data.get("accessibility", ""), data.get("facilities", ""),
            data.get("contact") or "Not provided", verified, source, now())
    with conn() as c:
        if shelter_id:
            c.execute("UPDATE shelters SET name=?,node=?,capacity=?,occupied=?,accessibility=?,facilities=?,contact=?,"
                      "verified=?,source=?,updated_at=? WHERE id=?", (*vals, shelter_id))
        else:
            c.execute("INSERT INTO shelters(name,node,capacity,occupied,accessibility,facilities,contact,verified,source,updated_at)"
                      " VALUES(?,?,?,?,?,?,?,?,?,?)", vals)
    return verified


def delete_shelter(shelter_id):
    with conn() as c:
        c.execute("DELETE FROM shelters WHERE id=?", (shelter_id,))


# ---- incidents & roads ----
def add_incident(dtype, severity, node, description, road_ids=()):
    if dtype not in DISASTERS or severity not in SEVERITIES:
        raise ValueError("Invalid disaster type or severity.")
    with conn() as c:
        cur = c.execute("INSERT INTO incidents(disaster_type,severity,node,description,status,created_at,updated_at)"
                        " VALUES(?,?,?,?,?,?,?)", (dtype, severity, node, description.strip()[:500], "Reported", now(), now()))
        for rid in road_ids:
            c.execute("INSERT OR REPLACE INTO road_status VALUES(?,?,?,?)",
                      (rid, "closed", f"Unverified report #{cur.lastrowid}", now()))
        return cur.lastrowid


def list_incidents():
    with conn() as c:
        return [dict(r) for r in c.execute("SELECT * FROM incidents ORDER BY id DESC")]


def active_incidents():
    return [i for i in list_incidents() if i["status"] != "Resolved"]


def update_incident_status(incident_id, status):
    if status not in STATUSES:
        raise ValueError("Invalid status.")
    with conn() as c:
        c.execute("UPDATE incidents SET status=?, updated_at=? WHERE id=?", (status, now(), incident_id))


def closed_road_ids():
    with conn() as c:
        return {r["road_id"] for r in c.execute("SELECT road_id FROM road_status WHERE status='closed'")}


def closed_road_details():
    with conn() as c:
        return [dict(r) for r in c.execute("SELECT * FROM road_status WHERE status='closed'")]


def close_road(road_id, reason="Manual restriction"):
    with conn() as c:
        c.execute("INSERT OR REPLACE INTO road_status VALUES(?,?,?,?)", (road_id, "closed", reason, now()))


def reopen_road(road_id):
    with conn() as c:
        c.execute("DELETE FROM road_status WHERE road_id=?", (road_id,))


# ---- history ----
def log_route(origin, dest, route, simulated):
    with conn() as c:
        c.execute("INSERT INTO route_history(created_at,origin,destination,algorithm,distance_km,time_min,exposure,simulated)"
                  " VALUES(?,?,?,?,?,?,?,?)", (now(), origin, dest, route["algorithm"], route["distance_km"],
                                               route["time_min"], route["exposure"], int(simulated)))


def route_history(limit=50):
    with conn() as c:
        return [dict(r) for r in c.execute("SELECT * FROM route_history ORDER BY id DESC LIMIT ?", (limit,))]
