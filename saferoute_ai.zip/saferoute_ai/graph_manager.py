"""Road graph construction, hazard zones, closures and cost functions (NetworkX)."""
from __future__ import annotations
import networkx as nx
from data_loader import haversine_km

SEV_WEIGHT = {"Low": 0.3, "Medium": 0.6, "High": 1.0}
SEV_RADIUS_KM = {"Low": 0.8, "Medium": 1.5, "High": 2.5}
TYPE_FACTOR = {"Flood": 1.0, "Earthquake": 1.2, "Cyclone": 1.6, "Wildfire": 1.3, "Other": 1.0}
OBJECTIVES = ["Safety-aware (recommended)", "Fastest", "Shortest distance"]


def make_zone(node, dtype, severity, label, source):
    """A circular hazard zone centred on a node (simplified, for demonstration)."""
    return {"lat": node["lat"], "lon": node["lon"], "type": dtype, "severity": severity,
            "radius_km": round(SEV_RADIUS_KM[severity] * TYPE_FACTOR.get(dtype, 1.0), 2),
            "label": label, "source": source}


class RoadGraph:
    def __init__(self, nodes, roads):
        self.nodes, self.roads = nodes, {r["id"]: r for r in roads}
        self.G = nx.Graph()
        for nid, n in nodes.items():
            self.G.add_node(nid, **n)
        for r in roads:
            self.G.add_edge(r["u"], r["v"], hazard=0.0, **r)
        self.zones = []

    def apply_zones(self, zones):
        """Recompute per-edge hazard (0..1): severity * (1 - distance/radius), max over zones."""
        self.zones = list(zones)
        for u, v, d in self.G.edges(data=True):
            a, b = self.nodes[u], self.nodes[v]
            pts = [(a["lat"], a["lon"]), ((a["lat"] + b["lat"]) / 2, (a["lon"] + b["lon"]) / 2), (b["lat"], b["lon"])]
            h = 0.0
            for z in zones:
                dmin = min(haversine_km(p[0], p[1], z["lat"], z["lon"]) for p in pts)
                h = max(h, SEV_WEIGHT[z["severity"]] * max(0.0, 1 - dmin / z["radius_km"]))
            d["hazard"] = round(min(h, 1.0), 3)

    def hazard_ranking(self):
        """Edge ids sorted by hazard, highest first (only those with hazard > 0)."""
        ranked = sorted(((d["hazard"], d["id"]) for _, _, d in self.G.edges(data=True) if d["hazard"] > 0), reverse=True)
        return [eid for _, eid in ranked]

    def edge(self, u, v):
        return self.G.edges[u, v]

    def time_min(self, d):
        return d["length_km"] / d["speed_kmh"] * 60 * (1 + d["congestion"])

    def edge_cost(self, d, objective, hazard_weight):
        """Always >= 0. Safety-aware = travel time inflated by hazard exposure."""
        if objective == "Shortest distance":
            return d["length_km"]
        t = self.time_min(d)
        return t if objective == "Fastest" else t * (1 + hazard_weight * d["hazard"])

    def adjacency(self, objective="Safety-aware (recommended)", hazard_weight=3.0, closed=frozenset()):
        """Directed adjacency dict with closed roads excluded entirely."""
        adj = {n: [] for n in self.G.nodes}
        for u, v, d in self.G.edges(data=True):
            if d["id"] in closed:
                continue
            w = self.edge_cost(d, objective, hazard_weight)
            adj[u].append((v, w)); adj[v].append((u, w))
        return adj

    def path_metrics(self, path, closed=frozenset()):
        dist = time = haz_len = 0.0
        hazard_segments, closed_hits, ids = 0, 0, []
        for u, v in zip(path, path[1:]):
            d = self.edge(u, v)
            dist += d["length_km"]; time += self.time_min(d); haz_len += d["hazard"] * d["length_km"]
            hazard_segments += d["hazard"] > 0
            closed_hits += d["id"] in closed
            ids.append(d["id"])
        return {"distance_km": round(dist, 2), "time_min": round(time, 1), "segments": len(ids),
                "exposure": round(100 * haz_len / dist, 1) if dist else 0.0,
                "hazard_segments": int(hazard_segments), "closed_hits": closed_hits, "edge_ids": ids}

    def nearest_node(self, lat, lon):
        return min(self.nodes.values(), key=lambda n: haversine_km(lat, lon, n["lat"], n["lon"]))["id"]
